/**
 * Fixed stars and other celestial objects
 * This file will be used in future updates to include fixed stars calculations
 */

// Major fixed stars data (name, longitude, latitude, magnitude)
const fixedStars = [
  { name: "Sirius", longitude: 104.05, latitude: -39.61, magnitude: -1.46 },
  { name: "Canopus", longitude: 96.33, latitude: -75.76, magnitude: -0.72 },
  { name: "Arcturus", longitude: 213.91, latitude: 19.18, magnitude: -0.05 },
  { name: "Rigel Kentaurus", longitude: 229.64, latitude: -60.83, magnitude: -0.01 },
  { name: "Vega", longitude: 279.23, latitude: 38.78, magnitude: 0.03 },
  { name: "Capella", longitude: 79.17, latitude: 45.99, magnitude: 0.08 },
  { name: "Rigel", longitude: 78.63, latitude: -31.09, magnitude: 0.13 },
  { name: "Procyon", longitude: 114.83, latitude: -16.13, magnitude: 0.4 },
  { name: "Betelgeuse", longitude: 88.79, latitude: -16.02, magnitude: 0.45 },
  { name: "Achernar", longitude: 15.35, latitude: -61.57, magnitude: 0.45 },
  { name: "Hadar", longitude: 240.08, latitude: -60.37, magnitude: 0.61 },
  { name: "Altair", longitude: 301.29, latitude: 8.87, magnitude: 0.76 },
  { name: "Acrux", longitude: 208.67, latitude: -63.1, magnitude: 0.77 },
  { name: "Aldebaran", longitude: 69.85, latitude: -5.47, magnitude: 0.87 },
  { name: "Spica", longitude: 203.53, latitude: -2.06, magnitude: 0.98 },
  { name: "Antares", longitude: 247.64, latitude: -4.57, magnitude: 1.06 },
  { name: "Pollux", longitude: 113.21, latitude: 6.68, magnitude: 1.16 },
  { name: "Fomalhaut", longitude: 342.25, latitude: -29.62, magnitude: 1.17 },
  { name: "Deneb", longitude: 305.25, latitude: 45.28, magnitude: 1.25 },
  { name: "Regulus", longitude: 149.74, latitude: 0.46, magnitude: 1.36 }
];

// Calculate fixed star positions for a given date
function calculateFixedStarPositions(date) {
  // This is a simplified placeholder
  // In a real implementation, this would calculate precession and other effects
  
  // For now, we'll just return the fixed positions
  return fixedStars;
}

// Check for conjunctions between planets and fixed stars
function checkStarConjunctions(planetPositions, orb = 1.0) {
  const conjunctions = [];
  const stars = calculateFixedStarPositions(planetPositions.date);
  
  // Check each planet against each star
  for (const planet in planetPositions) {
    if (planet === 'date') continue;
    
    const planetLong = planetPositions[planet].siderealLongitude;
    
    for (const star of stars) {
      // Calculate angular distance
      let diff = Math.abs(planetLong - star.longitude);
      if (diff > 180) diff = 360 - diff;
      
      // Check if within orb
      if (diff <= orb) {
        conjunctions.push({
          planet: planet,
          star: star.name,
          orb: diff.toFixed(2)
        });
      }
    }
  }
  
  return conjunctions;
}

// Export functions for use in other modules
window.calculateFixedStarPositions = calculateFixedStarPositions;
window.checkStarConjunctions = checkStarConjunctions;
