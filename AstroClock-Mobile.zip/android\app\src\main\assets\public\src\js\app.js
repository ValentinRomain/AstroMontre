// Import Capacitor core
import { Capacitor } from '@capacitor/core';

// Initialize the app
document.addEventListener('DOMContentLoaded', async function() {
  console.log('AstroClock App initialized');

  try {
    // Import our modules dynamically to handle potential errors
    await import('./planets.js');
    console.log('Planets module loaded');

    await import('./ephemerides.js');
    console.log('Ephemerides module loaded');

    await import('./stars.js');
    console.log('Stars module loaded');

    try {
      await import('./daily-aspects.js');
      console.log('Daily aspects module loaded');
    } catch (error) {
      console.error('Error loading daily-aspects.js:', error);
    }

    await import('./main.js');
    console.log('Main module loaded');
  } catch (error) {
    console.error('Error loading modules:', error);
  }

  // Check if running on a device
  if (Capacitor.isNativePlatform()) {
    console.log('Running on a native platform');

    // Add mobile-specific adjustments
    document.body.classList.add('mobile-device');

    // Handle back button for Android
    document.addEventListener('backbutton', function(e) {
      e.preventDefault();
      // Show a confirmation dialog to exit the app
      if (confirm('Voulez-vous quitter l\'application?')) {
        navigator.app.exitApp();
      }
    }, false);

    // Prevent screen from sleeping during use
    if (Capacitor.Plugins.KeepAwake) {
      Capacitor.Plugins.KeepAwake.keepAwake();
    }
  } else {
    console.log('Running in a browser');
  }
});
