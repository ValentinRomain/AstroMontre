/**
 * Daily Aspects Planning - Calculates and displays aspects throughout the day
 */

// Global variables
let dailyAspectsData = [];
let currentHour = 0;
let dailyAspectsInterval = null;
let selectedOrb = 0.5;

// Charger les aspects sélectionnés depuis le localStorage ou utiliser les valeurs par défaut
let selectedAspects = JSON.parse(localStorage.getItem('selectedAspects')) ||
  ['conjunction', 'opposition', 'trine', 'square', 'sextile', 'quincunx', 'semisextile', 'quintile', 'biquintile'];

// Utiliser les variables globales de sidepanel.js si elles existent, sinon charger depuis localStorage ou utiliser les valeurs par défaut
let selectedTransitPlanets = window.selectedTransitPlanets ||
  JSON.parse(localStorage.getItem('selectedTransitPlanets')) ||
  ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];

let selectedNatalPlanets = window.selectedNatalPlanets ||
  JSON.parse(localStorage.getItem('selectedNatalPlanets')) ||
  ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];

// Aspects personnalisés (stockés globalement pour être accessibles partout)
window.customAspects = window.customAspects || JSON.parse(localStorage.getItem('customAspects')) || [];

// Fonction pour sauvegarder les préférences dans le localStorage
function savePreferences() {
  localStorage.setItem('selectedAspects', JSON.stringify(selectedAspects));
  localStorage.setItem('selectedTransitPlanets', JSON.stringify(selectedTransitPlanets));
  localStorage.setItem('selectedNatalPlanets', JSON.stringify(selectedNatalPlanets));
  localStorage.setItem('customAspects', JSON.stringify(window.customAspects));
  localStorage.setItem('selectedOrb', selectedOrb.toString());

  // Afficher un message de confirmation
  const saveMessage = document.createElement('div');
  saveMessage.className = 'save-confirmation';
  saveMessage.textContent = 'Préférences sauvegardées !';
  document.body.appendChild(saveMessage);

  // Supprimer le message après 2 secondes
  setTimeout(() => {
    if (document.body.contains(saveMessage)) {
      document.body.removeChild(saveMessage);
    }
  }, 2000);
}

// Initialize the daily aspects planning
function initDailyAspectsPlanning() {
  // Update the current date display
  updateCurrentDateDisplay();

  // Set up interval to update the current date and time every minute
  setInterval(updateCurrentDateDisplay, 60000);

  // Set up orb slider
  setupOrbSlider();

  // Set up filter controls
  setupFilterControls();

  // Set up custom aspect controls
  setupCustomAspectControls();

  // Initial calculation of daily aspects
  calculateDailyAspects();
}

// Set up the orb slider control
function setupOrbSlider() {
  const orbSlider = document.getElementById('aspect-orb-slider');
  const orbValue = document.getElementById('orb-value');

  if (orbSlider && orbValue) {
    // Charger la valeur depuis localStorage si elle existe
    const savedOrb = localStorage.getItem('selectedOrb');
    if (savedOrb) {
      selectedOrb = parseFloat(savedOrb);
    }

    // Set initial value
    orbSlider.value = selectedOrb;
    orbValue.textContent = selectedOrb + '°';

    // Add event listener for changes
    orbSlider.addEventListener('input', function() {
      selectedOrb = parseFloat(this.value);
      orbValue.textContent = selectedOrb + '°';
    });

    // Recalculate aspects when slider is released
    orbSlider.addEventListener('change', function() {
      calculateDailyAspects();
      // Sauvegarder la valeur dans localStorage
      localStorage.setItem('selectedOrb', selectedOrb.toString());
    });
  }
}

// Set up the filter controls
function setupFilterControls() {
  // Get the apply filters button
  const applyFiltersBtn = document.getElementById('apply-filters-btn');

  // Initialize checkboxes based on current selections
  initializeCheckboxes();

  // Ajouter un bouton pour sauvegarder les préférences
  const savePreferencesBtn = document.createElement('button');
  savePreferencesBtn.id = 'save-preferences-btn';
  savePreferencesBtn.className = 'btn btn-primary save-preferences-btn';
  savePreferencesBtn.textContent = 'Sauvegarder mes préférences';

  // Insérer le bouton après le bouton d'application des filtres
  if (applyFiltersBtn && applyFiltersBtn.parentNode) {
    applyFiltersBtn.parentNode.insertBefore(savePreferencesBtn, applyFiltersBtn.nextSibling);
  }

  // Ajouter un gestionnaire d'événements pour le bouton de sauvegarde
  if (savePreferencesBtn) {
    savePreferencesBtn.addEventListener('click', function() {
      savePreferences();
    });
  }

  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', function() {
      // Get selected aspects (standard aspects)
      selectedAspects = [];
      document.querySelectorAll('.aspects-filter input[type="checkbox"]:checked').forEach(checkbox => {
        selectedAspects.push(checkbox.value);
      });

      // Get selected custom aspects
      document.querySelectorAll('#custom-aspects-container input[type="checkbox"]:checked').forEach(checkbox => {
        selectedAspects.push(checkbox.value);
      });

      // Get selected transit planets
      selectedTransitPlanets = [];
      document.querySelectorAll('.transit-planets-filter input[type="checkbox"]:checked').forEach(checkbox => {
        selectedTransitPlanets.push(checkbox.value);
      });

      // Get selected natal planets
      selectedNatalPlanets = [];
      document.querySelectorAll('.natal-planets-filter input[type="checkbox"]:checked').forEach(checkbox => {
        selectedNatalPlanets.push(checkbox.value);
      });

      // Sauvegarder les préférences dans localStorage
      localStorage.setItem('selectedAspects', JSON.stringify(selectedAspects));
      localStorage.setItem('selectedTransitPlanets', JSON.stringify(selectedTransitPlanets));
      localStorage.setItem('selectedNatalPlanets', JSON.stringify(selectedNatalPlanets));

      // Recalculate aspects with new filters
      calculateDailyAspects();
    });
  }
}

// Initialize checkboxes based on current selections
function initializeCheckboxes() {
  // D'abord, décocher toutes les cases
  document.querySelectorAll('.aspects-filter input[type="checkbox"], .transit-planets-filter input[type="checkbox"], .natal-planets-filter input[type="checkbox"]').forEach(checkbox => {
    checkbox.checked = false;
  });

  // Set aspect checkboxes
  selectedAspects.forEach(aspect => {
    // Gérer à la fois les aspects standard et personnalisés
    const checkbox = document.getElementById(`filter-${aspect}`);
    if (checkbox) {
      checkbox.checked = true;
    }
  });

  // Set transit planet checkboxes
  selectedTransitPlanets.forEach(planet => {
    const checkbox = document.getElementById(`filter-transit-${planet}`);
    if (checkbox) {
      checkbox.checked = true;
    }
  });

  // Set natal planet checkboxes
  selectedNatalPlanets.forEach(planet => {
    const checkbox = document.getElementById(`filter-natal-${planet}`);
    if (checkbox) {
      checkbox.checked = true;
    }
  });

  // Set custom aspect checkboxes
  if (window.customAspects && window.customAspects.length > 0) {
    window.customAspects.forEach(aspect => {
      // Vérifier si cet aspect personnalisé est dans la liste des aspects sélectionnés
      if (selectedAspects.includes(`custom-${aspect.id}`)) {
        const checkbox = document.getElementById(`filter-custom-${aspect.id}`);
        if (checkbox) {
          checkbox.checked = true;
        }
      }
    });
  }
}

// Set up custom aspect controls
function setupCustomAspectControls() {
  const addCustomAspectBtn = document.getElementById('add-custom-aspect-btn');

  if (addCustomAspectBtn) {
    addCustomAspectBtn.addEventListener('click', showCustomAspectForm);
  }

  // Display existing custom aspects
  displayCustomAspects();
}

// Display custom aspects in the filter list
function displayCustomAspects() {
  const customAspectsContainer = document.getElementById('custom-aspects-container');

  if (!customAspectsContainer) return;

  // Clear container
  customAspectsContainer.innerHTML = '';

  // Add each custom aspect to the filter list
  if (window.customAspects && window.customAspects.length > 0) {
    window.customAspects.forEach(aspect => {
      const aspectOption = document.createElement('div');
      aspectOption.className = 'filter-option';
      aspectOption.innerHTML = `
        <input type="checkbox" id="filter-custom-${aspect.id}" value="custom-${aspect.id}" checked>
        <label for="filter-custom-${aspect.id}">${aspect.name} (${aspect.angle}°)</label>
        <div class="aspect-actions">
          <button class="edit-custom-aspect" data-id="${aspect.id}" title="Modifier cet aspect">✎</button>
          <button class="delete-custom-aspect" data-id="${aspect.id}" title="Supprimer cet aspect">×</button>
        </div>
      `;
      customAspectsContainer.appendChild(aspectOption);

      // Add event listeners for edit and delete buttons
      const editBtn = aspectOption.querySelector('.edit-custom-aspect');
      const deleteBtn = aspectOption.querySelector('.delete-custom-aspect');

      if (editBtn) {
        editBtn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          showEditAspectForm(id);
        });
      }

      if (deleteBtn) {
        deleteBtn.addEventListener('click', function() {
          const id = this.getAttribute('data-id');
          deleteCustomAspect(id);
        });
      }
    });
  }
}

// Show form to add a custom aspect
function showCustomAspectForm() {
  // Create modal overlay
  const modalOverlay = document.createElement('div');
  modalOverlay.className = 'modal-overlay';
  document.body.appendChild(modalOverlay);

  // Create modal content
  const modalContent = document.createElement('div');
  modalContent.className = 'modal-content';
  modalContent.innerHTML = `
    <h3>Ajouter un aspect personnalisé</h3>
    <div class="form-group">
      <label for="custom-aspect-name">Nom de l'aspect:</label>
      <input type="text" id="custom-aspect-name" placeholder="Ex: Septile">
    </div>
    <div class="form-group">
      <label for="custom-aspect-angle">Angle (degrés):</label>
      <input type="number" id="custom-aspect-angle" min="0" max="180" step="0.1" placeholder="Ex: 51.43">
    </div>
    <div class="form-actions">
      <button id="cancel-custom-aspect" class="btn btn-secondary">Annuler</button>
      <button id="save-custom-aspect" class="btn btn-primary">Ajouter</button>
    </div>
  `;
  modalOverlay.appendChild(modalContent);

  // Add event listeners
  const cancelBtn = document.getElementById('cancel-custom-aspect');
  const saveBtn = document.getElementById('save-custom-aspect');
  const nameInput = document.getElementById('custom-aspect-name');
  const angleInput = document.getElementById('custom-aspect-angle');

  if (cancelBtn) {
    cancelBtn.addEventListener('click', function() {
      document.body.removeChild(modalOverlay);
    });
  }

  if (saveBtn && nameInput && angleInput) {
    saveBtn.addEventListener('click', function() {
      const name = nameInput.value.trim();
      const angle = parseFloat(angleInput.value);

      if (name && !isNaN(angle) && angle >= 0 && angle <= 180) {
        addCustomAspect(name, angle);
        document.body.removeChild(modalOverlay);
      } else {
        alert('Veuillez entrer un nom et un angle valide (entre 0 et 180 degrés).');
      }
    });
  }
}

// Show form to edit a custom aspect
function showEditAspectForm(id) {
  // Find the aspect to edit
  const aspect = window.customAspects.find(a => a.id === id);
  if (!aspect) return;

  // Create modal overlay
  const modalOverlay = document.createElement('div');
  modalOverlay.className = 'modal-overlay';
  document.body.appendChild(modalOverlay);

  // Create modal content
  const modalContent = document.createElement('div');
  modalContent.className = 'modal-content';
  modalContent.innerHTML = `
    <h3>Modifier un aspect personnalisé</h3>
    <div class="form-group">
      <label for="edit-aspect-name">Nom de l'aspect:</label>
      <input type="text" id="edit-aspect-name" value="${aspect.name}">
    </div>
    <div class="form-group">
      <label for="edit-aspect-angle">Angle (degrés):</label>
      <input type="number" id="edit-aspect-angle" min="0" max="180" step="0.1" value="${aspect.angle}">
    </div>
    <div class="form-actions">
      <button id="cancel-edit-aspect" class="btn btn-secondary">Annuler</button>
      <button id="update-aspect" class="btn btn-primary">Mettre à jour</button>
    </div>
  `;
  modalOverlay.appendChild(modalContent);

  // Add event listeners
  const cancelBtn = document.getElementById('cancel-edit-aspect');
  const updateBtn = document.getElementById('update-aspect');
  const nameInput = document.getElementById('edit-aspect-name');
  const angleInput = document.getElementById('edit-aspect-angle');

  if (cancelBtn) {
    cancelBtn.addEventListener('click', function() {
      document.body.removeChild(modalOverlay);
    });
  }

  if (updateBtn && nameInput && angleInput) {
    updateBtn.addEventListener('click', function() {
      const name = nameInput.value.trim();
      const angle = parseFloat(angleInput.value);

      if (name && !isNaN(angle) && angle >= 0 && angle <= 180) {
        updateCustomAspect(id, name, angle);
        document.body.removeChild(modalOverlay);
      } else {
        alert('Veuillez entrer un nom et un angle valide (entre 0 et 180 degrés).');
      }
    });
  }
}

// Add a custom aspect
function addCustomAspect(name, angle) {
  // Generate a unique ID
  const id = Date.now().toString();

  // Create the custom aspect
  const customAspect = {
    id: id,
    name: name,
    angle: angle
  };

  // Add to the global array
  if (!window.customAspects) {
    window.customAspects = [];
  }

  window.customAspects.push(customAspect);

  // Sauvegarder dans localStorage
  localStorage.setItem('customAspects', JSON.stringify(window.customAspects));

  // Update the display
  displayCustomAspects();

  // Add to selected aspects
  selectedAspects.push(`custom-${id}`);

  // Sauvegarder les aspects sélectionnés
  localStorage.setItem('selectedAspects', JSON.stringify(selectedAspects));

  // Recalculate aspects
  calculateDailyAspects();
}

// Update a custom aspect
function updateCustomAspect(id, name, angle) {
  // Find the aspect to update
  const aspectIndex = window.customAspects.findIndex(aspect => aspect.id === id);
  if (aspectIndex === -1) return;

  // Update the aspect
  window.customAspects[aspectIndex].name = name;
  window.customAspects[aspectIndex].angle = angle;

  // Sauvegarder dans localStorage
  localStorage.setItem('customAspects', JSON.stringify(window.customAspects));

  // Update the display
  displayCustomAspects();

  // Recalculate aspects
  calculateDailyAspects();
}

// Delete a custom aspect
function deleteCustomAspect(id) {
  // Confirm deletion
  if (!confirm('Êtes-vous sûr de vouloir supprimer cet aspect personnalisé ?')) {
    return;
  }

  // Remove from the global array
  window.customAspects = window.customAspects.filter(aspect => aspect.id !== id);

  // Sauvegarder dans localStorage
  localStorage.setItem('customAspects', JSON.stringify(window.customAspects));

  // Remove from selected aspects
  const index = selectedAspects.indexOf(`custom-${id}`);
  if (index !== -1) {
    selectedAspects.splice(index, 1);

    // Sauvegarder les aspects sélectionnés
    localStorage.setItem('selectedAspects', JSON.stringify(selectedAspects));
  }

  // Update the display
  displayCustomAspects();

  // Recalculate aspects
  calculateDailyAspects();
}

// Update the current date display
function updateCurrentDateDisplay() {
  const currentDateElement = document.getElementById('current-date');
  if (currentDateElement) {
    const now = new Date();
    const formattedDate = now.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    currentDateElement.textContent = `Date du jour : ${formattedDate}`;
  }
}

// Calculate daily aspects
function calculateDailyAspects() {
  // Update the orb header
  const orbHeader = document.getElementById('aspects-orb-header');
  if (orbHeader) {
    orbHeader.textContent = `Aspects orb ${selectedOrb}°`;
  }

  // Get birth date
  const birthDateInput = document.getElementById('birth-date');
  const birthHourInput = document.getElementById('birth-hour');
  const birthMinuteInput = document.getElementById('birth-minute');

  if (!birthDateInput || !birthHourInput || !birthMinuteInput) {
    console.error('Birth date inputs not found');
    return;
  }

  const birthDate = new Date(birthDateInput.value);
  birthDate.setHours(
    parseInt(birthHourInput.value) || 0,
    parseInt(birthMinuteInput.value) || 0,
    0
  );

  // Get current date for transit
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const currentDay = now.getDate();

  // Calculate birth positions
  const birthPositions = calculatePlanetaryPositions(birthDate);

  // Calculate aspects for each hour of the day
  dailyAspectsData = [];

  for (let hour = 0; hour < 24; hour++) {
    const transitDate = new Date(currentYear, currentMonth, currentDay, hour, 0, 0);
    const transitPositions = calculatePlanetaryPositions(transitDate);

    // Calculate aspects between birth and transit planets
    const hourAspects = calculateHourAspects(birthPositions, transitPositions);
    dailyAspectsData.push({
      hour: hour,
      aspects: hourAspects
    });
  }

  // Display the aspects in the table
  displayDailyAspects();
}

// Calculate aspects for a specific hour
function calculateHourAspects(birthPositions, transitPositions) {
  const aspects = [];
  const aspectAngles = {
    "conjunction": 0,
    "opposition": 180,
    "trine": 120,
    "square": 90,
    "sextile": 60,
    "quincunx": 150,
    "semisextile": 30,
    "quintile": 72,
    "biquintile": 144
  };

  // Add custom aspects to the aspectAngles object
  if (window.customAspects && window.customAspects.length > 0) {
    window.customAspects.forEach(aspect => {
      aspectAngles[`custom-${aspect.id}`] = aspect.angle;
    });
  }

  // Check for aspects between birth and transit planets
  for (const birthPlanet of selectedNatalPlanets) {
    if (!birthPositions[birthPlanet]) continue;

    for (const transitPlanet of selectedTransitPlanets) {
      if (!transitPositions[transitPlanet]) continue;

      const birthLong = birthPositions[birthPlanet].siderealLongitude;
      const transitLong = transitPositions[transitPlanet].siderealLongitude;

      // Calculate the angular difference
      let diff = Math.abs(transitLong - birthLong);
      if (diff > 180) diff = 360 - diff;

      // Check for aspects
      for (const aspectType of selectedAspects) {
        const aspectAngle = aspectAngles[aspectType];
        if (aspectAngle === undefined) continue;

        const orb = Math.abs(diff - aspectAngle);
        if (orb <= selectedOrb) {
          // Get custom aspect name if it's a custom aspect
          let aspectName = aspectType;
          if (aspectType.startsWith('custom-')) {
            const aspectId = aspectType.replace('custom-', '');
            const customAspect = window.customAspects.find(a => a.id === aspectId);
            if (customAspect) {
              aspectName = customAspect.name;
            }
          }

          aspects.push({
            birthPlanet: birthPlanet,
            transitPlanet: transitPlanet,
            aspect: aspectName,
            aspectType: aspectType,
            orb: orb.toFixed(2),
            exact: orb < 0.1
          });
        }
      }
    }
  }

  return aspects;
}

// Display daily aspects in the table
function displayDailyAspects() {
  const tableBody = document.getElementById('daily-aspects-body');
  if (!tableBody) return;

  // Clear table
  tableBody.innerHTML = '';

  // Get current hour
  const now = new Date();
  currentHour = now.getHours();

  // Create a map to track which aspects have been displayed
  const displayedAspects = new Map();

  // Process each hour's aspects
  for (const hourData of dailyAspectsData) {
    for (const aspect of hourData.aspects) {
      // Create a unique key for this aspect
      const aspectKey = `${aspect.birthPlanet}-${aspect.transitPlanet}-${aspect.aspectType}`;

      // Check if we've already displayed this aspect
      if (!displayedAspects.has(aspectKey)) {
        // Create a new row for this aspect
        const row = document.createElement('tr');

        // Add the aspect label cell
        const labelCell = document.createElement('td');
        labelCell.className = 'aspect-label';

        // Format the aspect label with planet symbols
        const birthPlanetSymbol = PLANET_SYMBOLS[aspect.birthPlanet] || aspect.birthPlanet;
        const transitPlanetSymbol = PLANET_SYMBOLS[aspect.transitPlanet] || aspect.transitPlanet;

        labelCell.innerHTML = `${transitPlanetSymbol} ${aspect.aspect} ${birthPlanetSymbol}`;
        row.appendChild(labelCell);

        // Add cells for each hour
        for (let h = 0; h < 25; h++) {
          const cell = document.createElement('td');

          // Check if this aspect is active at this hour
          const hourAspects = dailyAspectsData.find(data => data.hour === h)?.aspects || [];
          const isActive = hourAspects.some(a =>
            a.birthPlanet === aspect.birthPlanet &&
            a.transitPlanet === aspect.transitPlanet &&
            a.aspectType === aspect.aspectType
          );

          if (isActive) {
            // Find the aspect to get the orb
            const hourAspect = hourAspects.find(a =>
              a.birthPlanet === aspect.birthPlanet &&
              a.transitPlanet === aspect.transitPlanet &&
              a.aspectType === aspect.aspectType
            );

            cell.className = 'aspect-active';
            if (hourAspect.exact) {
              cell.className += ' aspect-exact';
            }

            // Add the orb as a tooltip
            cell.title = `Orb: ${hourAspect.orb}°`;
          }

          // Highlight the current hour
          if (h === currentHour) {
            cell.classList.add('current-hour');
          }

          row.appendChild(cell);
        }

        tableBody.appendChild(row);

        // Mark this aspect as displayed
        displayedAspects.set(aspectKey, true);
      }
    }
  }

  // If no aspects were found, show a message
  if (displayedAspects.size === 0) {
    const row = document.createElement('tr');
    const cell = document.createElement('td');
    cell.colSpan = 26;
    cell.textContent = 'Aucun aspect trouvé avec les filtres actuels.';
    cell.className = 'no-aspects-message';
    row.appendChild(cell);
    tableBody.appendChild(row);
  }
}

// Initialize the daily aspects planning when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  initDailyAspectsPlanning();
});