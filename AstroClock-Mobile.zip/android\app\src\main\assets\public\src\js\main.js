// Global variables for planet filtering (accessibles globalement)
window.selectedTransitPlanets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];
window.selectedNatalPlanets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune'];

document.addEventListener('DOMContentLoaded', function() {
  // Global variables to store planet positions for redrawing
  let globalBirthPositions = null;
  let globalTransitPositions = null;

  // Get DOM elements
  const birthDateInput = document.getElementById('birth-date');
  const birthHourInput = document.getElementById('birth-hour');
  const birthMinuteInput = document.getElementById('birth-minute');
  const transitDateInput = document.getElementById('transit-date');
  const transitHourInput = document.getElementById('transit-hour');
  const transitMinuteInput = document.getElementById('transit-minute');
  const calculateBtn = document.getElementById('calculate-btn');
  const chartCanvas = document.getElementById('chart-canvas');
  const applyFiltersBtn = document.getElementById('apply-filters-btn');

  // Set default birth date (from user preferences or default)
  const defaultBirthDate = localStorage.getItem('birthDate') || '1991-12-17';
  const defaultBirthHour = localStorage.getItem('birthHour') || '7';
  const defaultBirthMinute = localStorage.getItem('birthMinute') || '27';

  if (birthDateInput) birthDateInput.value = defaultBirthDate;
  if (birthHourInput) birthHourInput.value = defaultBirthHour;
  if (birthMinuteInput) birthMinuteInput.value = defaultBirthMinute;

  // Initialize real-time updates
  window.autoUpdateEnabled = true;
  let realTimeInterval = null;

  // Update transit time to current time
  updateTransitTime();

  // Set up interval to update transit time every second
  setInterval(updateTransitTime, 1000);

  // Add event listener for calculate button
  if (calculateBtn) {
    calculateBtn.addEventListener('click', function() {
      // Save birth data to localStorage
      if (birthDateInput && birthDateInput.value) {
        localStorage.setItem('birthDate', birthDateInput.value);
      }
      if (birthHourInput && birthHourInput.value) {
        localStorage.setItem('birthHour', birthHourInput.value);
      }
      if (birthMinuteInput && birthMinuteInput.value) {
        localStorage.setItem('birthMinute', birthMinuteInput.value);
      }
      
      calculateChart();
    });
  }

  // Initialize filter checkboxes
  initializeFilterCheckboxes();

  // Add event listener for apply filters button
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', function() {
      // Get selected transit planets
      window.selectedTransitPlanets = [];
      document.querySelectorAll('.transit-planets-filter input[type="checkbox"]:checked').forEach(checkbox => {
        window.selectedTransitPlanets.push(checkbox.value);
      });

      // Get selected natal planets
      window.selectedNatalPlanets = [];
      document.querySelectorAll('.natal-planets-filter input[type="checkbox"]:checked').forEach(checkbox => {
        window.selectedNatalPlanets.push(checkbox.value);
      });

      // Mettre à jour les variables locales
      selectedTransitPlanets = window.selectedTransitPlanets;
      selectedNatalPlanets = window.selectedNatalPlanets;

      // Recalculate chart with new filters
      calculateChart();
      
      // Si la fonction calculateDailyAspects existe, l'appeler aussi
      if (typeof calculateDailyAspects === 'function') {
        calculateDailyAspects();
      }
    });
  }

  // Function to initialize filter checkboxes
  function initializeFilterCheckboxes() {
    // Set transit planet checkboxes
    window.selectedTransitPlanets.forEach(planet => {
      const checkbox = document.getElementById(`filter-transit-${planet}`);
      if (checkbox) {
        checkbox.checked = true;
      }
    });

    // Set natal planet checkboxes
    window.selectedNatalPlanets.forEach(planet => {
      const checkbox = document.getElementById(`filter-natal-${planet}`);
      if (checkbox) {
        checkbox.checked = true;
      }
    });
  }

  // Function to update transit time
  function updateTransitTime() {
    const now = new Date();
    
    if (transitDateInput && transitHourInput && transitMinuteInput) {
      // Format date as YYYY-MM-DD for input
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const formattedDate = `${year}-${month}-${day}`;
      
      transitDateInput.value = formattedDate;
      transitHourInput.value = now.getHours();
      transitMinuteInput.value = now.getMinutes();
      
      // Store seconds and milliseconds for precise calculations
      transitDateInput.dataset.seconds = now.getSeconds();
      transitDateInput.dataset.milliseconds = now.getMilliseconds();
      
      // If auto-update is enabled, recalculate the chart
      if (window.autoUpdateEnabled && globalBirthPositions) {
        calculateChart(true);
      }
    }
  }

  // Main function to calculate and display the chart
  function calculateChart(isRealTimeUpdate = false) {
    // Get birth date and time
    const birthDate = new Date(birthDateInput.value);
    birthDate.setHours(
      parseInt(birthHourInput.value) || 0,
      parseInt(birthMinuteInput.value) || 0,
      0
    );

    // Get transit date and time
    const transitDate = new Date(transitDateInput.value);

    // Include seconds and milliseconds for precise real-time calculations
    const transitSeconds = parseInt(transitDateInput.dataset.seconds || 0);
    const transitMilliseconds = parseInt(transitDateInput.dataset.milliseconds || 0);

    transitDate.setHours(
      parseInt(transitHourInput.value) || 0,
      parseInt(transitMinuteInput.value) || 0,
      transitSeconds,
      transitMilliseconds
    );

    // Calculate planetary positions
    const birthPositions = calculatePlanetaryPositions(birthDate);
    const transitPositions = calculatePlanetaryPositions(transitDate);

    // Store positions in global variables for redrawing on resize
    globalBirthPositions = birthPositions;
    globalTransitPositions = transitPositions;

    // Calculate and display aspects
    const aspects = calculateAspects(birthPositions, transitPositions);
    displayAspects(aspects);

    // Draw the chart
    drawChart(birthPositions, transitPositions);

    // Draw full 360° zodiac
    drawFullZodiac(birthPositions, transitPositions);

    // Draw circular proportional zodiac (30° mode)
    drawCircularProportionalZodiac(birthPositions, transitPositions);

    // Draw circular proportional zodiac (13.20° Nakshatra mode)
    drawNakshatraProportionalZodiac(birthPositions, transitPositions);

    // Draw lunar arc zodiac (minutes d'arc)
    drawLunarArcZodiac(transitPositions, birthPositions);

    // Draw seconds arc zodiac (secondes d'arc)
    drawSecondsArcZodiac(transitPositions, birthPositions);

    // Update daily aspects planning if not a real-time update
    if (!isRealTimeUpdate && typeof calculateDailyAspects === 'function') {
      calculateDailyAspects();
    }
  }

  // Function to calculate aspects between birth and transit positions
  function calculateAspects(birthPositions, transitPositions) {
    const aspects = [];
    const aspectTypes = [
      { name: 'conjonction', angle: 0, orb: 5 },
      { name: 'opposition', angle: 180, orb: 5 },
      { name: 'trigone', angle: 120, orb: 5 },
      { name: 'carré', angle: 90, orb: 5 },
      { name: 'sextile', angle: 60, orb: 5 },
      { name: 'quinconce', angle: 150, orb: 5 },
      { name: 'semi-sextile', angle: 30, orb: 3 }
    ];

    // Check for aspects between birth and transit planets
    for (const birthPlanet in birthPositions) {
      for (const transitPlanet in transitPositions) {
        // Skip if it's the same planet (e.g., Sun-Sun)
        if (birthPlanet === transitPlanet) continue;

        const birthLongitude = birthPositions[birthPlanet].siderealLongitude;
        const transitLongitude = transitPositions[transitPlanet].siderealLongitude;

        // Calculate angle between planets
        let angle = Math.abs(birthLongitude - transitLongitude);
        if (angle > 180) angle = 360 - angle;

        // Check for aspects
        for (const aspectType of aspectTypes) {
          const orb = Math.abs(angle - aspectType.angle);
          if (orb <= aspectType.orb) {
            aspects.push({
              birthPlanet: PLANET_SYMBOLS[birthPlanet] + ' ' + birthPlanet,
              transitPlanet: PLANET_SYMBOLS[transitPlanet] + ' ' + transitPlanet,
              aspect: aspectType.name,
              angle: angle,
              exactAngle: angle.toFixed(1),
              orb: orb.toFixed(1)
            });
          }
        }
      }
    }

    return aspects;
  }

  // Function to display aspects
  function displayAspects(aspects) {
    const container = document.getElementById('aspects-list');
    if (!container) return;

    // Clear container
    container.innerHTML = '';

    // Add header
    const header = document.createElement('h3');
    header.textContent = 'Aspects';
    container.appendChild(header);

    // If no aspects, show message
    if (aspects.length === 0) {
      const message = document.createElement('p');
      message.textContent = 'No aspects found.';
      container.appendChild(message);
      return;
    }

    // Add each aspect
    aspects.forEach(aspect => {
      const aspectItem = document.createElement('div');
      aspectItem.className = 'aspect-item';

      aspectItem.innerHTML = `
        <div class="aspect-planets">${aspect.birthPlanet} - ${aspect.transitPlanet}</div>
        <div class="aspect-type">
          <span class="aspect-name">${aspect.aspect}</span>
          <span class="aspect-angle">${aspect.exactAngle}°</span>
        </div>
      `;

      container.appendChild(aspectItem);
    });
  }

  // Add event listener for window resize to redraw the proportional zodiac
  let resizeTimeout;
  window.addEventListener('resize', function() {
    // Debounce the resize event to avoid excessive redraws
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(function() {
      // Get the current positions from the global variables
      if (globalBirthPositions && globalTransitPositions) {
        // Redraw the proportional zodiacs
        drawFullZodiac(globalBirthPositions, globalTransitPositions);
        drawCircularProportionalZodiac(globalBirthPositions, globalTransitPositions);
        drawNakshatraProportionalZodiac(globalBirthPositions, globalTransitPositions);
        drawLunarArcZodiac(globalTransitPositions, globalBirthPositions);
        drawSecondsArcZodiac(globalTransitPositions, globalBirthPositions);
      }
    }, 250);
  });

  // Initial calculation
  calculateChart();
});
